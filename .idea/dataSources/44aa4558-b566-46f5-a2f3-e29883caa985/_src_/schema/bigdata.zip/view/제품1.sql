CREATE VIEW `제품1` AS
  SELECT
    `bigdata`.`products4`.`prodid`   AS `제품번호`,
    `bigdata`.`products4`.`stock`    AS `제고량`,
    `bigdata`.`products4`.`prdmaker` AS `제조업체`
  FROM `bigdata`.`products4`