CREATE VIEW `customersorders` AS
  SELECT
    `c`.`name`       AS `name`,
    `o2`.`saleprice` AS `saleprice`
  FROM (`bigdata`.`orders` `o2`
    JOIN `bigdata`.`customers1` `c` ON (`o2`.`custid` = `c`.`custid`))
  WHERE `o2`.`saleprice` >= 20000
  ORDER BY `c`.`name`