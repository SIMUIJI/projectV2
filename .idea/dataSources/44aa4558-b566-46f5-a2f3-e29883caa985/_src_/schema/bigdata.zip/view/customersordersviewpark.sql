CREATE VIEW `customersordersviewpark` AS
  SELECT
    `o2`.`saleprice` AS `saleprice`,
    `c`.`address`    AS `address`,
    `o2`.`orderdate` AS `orderdate`
  FROM (`bigdata`.`orders` `o2`
    JOIN `bigdata`.`customers1` `c` ON (`o2`.`custid` = `c`.`custid`))
  WHERE `c`.`name` = '박지성'
  ORDER BY `o2`.`saleprice`