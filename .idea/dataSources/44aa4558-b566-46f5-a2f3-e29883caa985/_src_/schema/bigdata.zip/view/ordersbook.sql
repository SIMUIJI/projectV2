CREATE VIEW `ordersbook` AS
  SELECT
    `b`.`bookname`  AS `bookname`,
    `o`.`saleprice` AS `saleprice`,
    `o`.`orderdate` AS `orderdate`
  FROM (`bigdata`.`orders` `o`
    JOIN `bigdata`.`book` `b` ON (`o`.`bookid` = `b`.`bookid`))
  ORDER BY `b`.`bookname`