CREATE VIEW `제품2` AS
  SELECT
    `p`.`prdname`  AS `제품번호`,
    `p`.`stock`    AS `제고량`,
    `p`.`prdmaker` AS `제조업체`
  FROM `bigdata`.`products4` `p`