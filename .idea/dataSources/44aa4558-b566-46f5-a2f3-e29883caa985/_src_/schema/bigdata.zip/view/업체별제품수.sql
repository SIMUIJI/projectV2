CREATE VIEW `업체별제품수` AS
  SELECT
    `p`.`prdmaker`      AS `prdmaker`,
    count(`p`.`prodid`) AS `제품수`
  FROM (`bigdata`.`products4` `p`
    JOIN `bigdata`.`orders4` `o`)
  GROUP BY `p`.`prdmaker`