CREATE VIEW `customersorders_nbo` AS
  SELECT
    `c`.`name`      AS `name`,
    `b`.`bookname`  AS `bookname`,
    `o`.`orderdate` AS `orderdate`
  FROM ((`bigdata`.`book` `b`
    JOIN `bigdata`.`orders` `o` ON (`b`.`bookid` = `o`.`bookid`)) JOIN `bigdata`.`customers1` `c`
      ON (`o`.`custid` = `c`.`custid`))
  ORDER BY `c`.`name`