CREATE VIEW `주문정보` AS
  SELECT
    `c`.`name`  AS `name`,
    `o`.`addr`  AS `addr`,
    `o`.`ordid` AS `ordid`,
    `p`.`price` AS `price`
  FROM ((`bigdata`.`customers4` `c`
    JOIN `bigdata`.`orders4` `o` ON (`c`.`custid` = `o`.`custid`)) JOIN `bigdata`.`products4` `p`
      ON (`o`.`prodid` = `p`.`prodid`))