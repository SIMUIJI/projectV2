CREATE VIEW `업체별제품수2` AS
  SELECT
    `p`.`prdmaker`      AS `업체명`,
    count(`p`.`prodid`) AS `제품수`
  FROM (`bigdata`.`products4` `p`
    JOIN `bigdata`.`orders4` `o`)
  GROUP BY `p`.`prdmaker`