CREATE VIEW `주문상품정보` AS
  SELECT
    `p`.`prdname`  AS `prdname`,
    `p`.`prdmaker` AS `prdmaker`,
    `o`.`ordid`    AS `ordid`,
    `p`.`price`    AS `price`
  FROM ((`bigdata`.`customers4` `c`
    JOIN `bigdata`.`orders4` `o` ON (`c`.`custid` = `o`.`custid`)) JOIN `bigdata`.`products4` `p`
      ON (`o`.`prodid` = `p`.`prodid`))