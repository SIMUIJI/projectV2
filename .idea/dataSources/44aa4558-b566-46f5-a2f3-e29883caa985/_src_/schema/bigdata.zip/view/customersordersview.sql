CREATE VIEW `customersordersview` AS
  SELECT
    `o2`.`custid`    AS `custid`,
    `c`.`name`       AS `name`,
    `o2`.`saleprice` AS `saleprice`,
    `c`.`address`    AS `address`
  FROM (`bigdata`.`orders` `o2`
    JOIN `bigdata`.`customers1` `c` ON (`o2`.`custid` = `c`.`custid`))
  ORDER BY `c`.`custid`