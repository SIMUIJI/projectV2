CREATE VIEW `사원정보` AS
  SELECT
    `bigdata`.`emploess2`.`first_name` AS `first_name`,
    `bigdata`.`emploess2`.`last_name`  AS `last_name`,
    `bigdata`.`emploess2`.`job_id`     AS `job_id`,
    `bigdata`.`emploess2`.`salary`     AS `salary`
  FROM `bigdata`.`emploess2`